Para ejecutar el codigo:

1) Situarse con el path en la carpeta 'CASTELLI_ESPINDOLA_LAREO_PASSANO\Codigo' y
agregar al path la carpeta 'Funciones'.
2) Ejecutar el script 'CODIGO_ENTERO' ingresando 'CODIGO_ENTERO' en el command windows.
